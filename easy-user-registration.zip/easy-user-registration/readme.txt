===  Easy User Registration ===
Contributors: encoresky
Requires at least: 5.0
Tested up to: 6.0.2
Requires PHP: 7.0
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A simple and easy user registration plugin for Wordpress. 

== Description ==

A simple frontend user registration plugin that adds functionality to add users from the front end.

A free, lightweight, and 100% responsive plugin with a simple designed user registration form ready for you to use.

== SHORTCODE ==

** [EASY_USER_REGISTRATION] **

For basic usage, use this shortcode on any page of your Wordpress.

== Installation ==

1.Upload the entire `easy-user-registration` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

OR

1. **Visit** Plugins > Add New
2. **Search** for "Easy User Registration"
3. **Install and Activate** Easy User Registration from your Plugins page
4. **Paste** the shortcode on a Wordpress page and get a simple and easy to use `user registration form`!

By using **[EASY_USER_REGISTRATON]** You will find a simply designed user registration form on your Wordpress page.

== Changelog ==

= 1.0 =
* Initial release


