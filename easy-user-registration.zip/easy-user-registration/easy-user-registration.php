<?php
/**
 * Plugin Name: Easy User Registration
 * Plugin URI: https://www.encoresky.com/
 * Description: A simple frontend user registration plugin that adds functionality to add users from the frontend. This plugin provides a shortcode for registration form which is [EASY_USER_REGISTRATION]. 
 * Version: 1.0.0
 * Author: EncoreSky Technologies
 * Requires at least: 5.0
 * Requires PHP: 7.0
 * Tested up to: 6.0
 * 
 * Text Domain: easy-user-registration
 * Domain Path: /languages/
 *
 * @package EasyUserRegistration
 * @author encoresky.com
 */

defined( 'ABSPATH' ) || exit;
// Check for required PHP version
if( version_compare( PHP_VERSION, '5.6.12', '<' ) ){
	deactivate_plugins( __DIR__ );
	wp_die( __( 'Please update your PHP to version 5.6.12 or higher, then try activate <strong>Easy User Registration</strong> again.', 'easy-user-registration' ) );
}

/**
 * Current plugin version.
 * Start at version 1.0.0
 * 
 */

define( 'EASY_USER_REGISTRATON_VERSION', '1.0.0' );

/**
 * Callback function for activation hook
 * 
 */ 
function activate_easy_user_registration() {
    
}

/**
 * Callback function for deactivation hook
 * 
 */ 
function deactivate_easy_user_registration() {

}

/**
 * The code that runs during plugin activation.
 * 
 */
register_activation_hook( __FILE__, 'activate_easy_user_registration' );

/**
 * The code that runs during plugin deactivation.
 * 
 */
register_deactivation_hook( __FILE__, 'deactivate_easy_user_registration' );



/**
 *  Include the main EasyUserRegistration class.
 * 
 */
require plugin_dir_path( __FILE__ ) . 'front-end/class-eur-user-registration.php';