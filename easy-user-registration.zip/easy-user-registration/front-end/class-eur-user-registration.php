<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * The file that defines the core plugin class*/


if( ! class_exists( 'easy_user_registration' ) ) {
	class easy_user_registration {
		/**
		* @var     object
		* @access  private
		* @since   1.0.0
		*/
		private static $_instance = null;

		/**
		* @var     string
		* @access  public
		* @since   1.0.0
		*/
		public $plugin_prefix = 'eur';

		/**
		 * The unique identifier of this plugin.
		 *
		 * @since    1.0.0
		 * @access   protected
		 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
		 */
		protected $plugin_name;

		/**
		 * The current version of the plugin.
		 *
		 * @since    1.0.0
		 * @access   protected
		 * @var      string    $version    The current version of the plugin.
		 */
		protected $version;
		
		/**
		 * Define the core functionality of the plugin.
		 *
		 * Set the plugin name and the plugin version that can be used throughout the plugin.
		 * Load the dependencies, define the locale, and set the hooks for the admin area and
		 * the public-facing side of the site.
		 *
		 * @since    1.0.0
		 */
		public function __construct() {
			if ( defined( 'easy_user_registration_VERSION' ) ) {
				$this->version = easy_user_registration_VERSION;
			} else {
				$this->version = '1.0.0';
			}
			$this->plugin_name = 'easy-user-registration';
			$this->plugin_url  = plugin_dir_url( __FILE__ );
			$this->plugin_path = plugin_dir_path( __FILE__ );
			add_action('init', array($this, 'eur_enqueue_scripts_callback'));
			add_action( 'init', array($this, 'load_text_domain') );
			add_shortcode('EASY_USER_REGISTRATION', array($this, 'eur_registration_form_shortcode'));
			add_action('wp_ajax_eur_register_user', array($this, 'eur_register_user_callback'));
			add_action('wp_ajax_nopriv_eur_register_user', array($this, 'eur_register_user_callback'));
		}
		
		
		/**
		 * Main easy_user_registration Instance
		 *
		 * Ensures only one instance of easy_user_registration is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see easy_user_registration()
		 * @return Main easy_user_registration instance
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		} // End instance()


		/**
         * Plugin textdomain loader
         */
        public function load_text_domain()
        {
            $locale = apply_filters('plugin_locale', get_locale(), 'easy-user-registration');
            $text_domain_to_load = 'easy-user-registration-'.$locale;
            //load_textdomain('easy-user-registration', WP_PLUGIN_DIR . "/easy-user-registration/languages/$text_domain_to_load.mo");
            load_textdomain('easy-user-registration', trailingslashit(dirname(__FILE__)) . "../languages/$text_domain_to_load.mo");
        }

		/**
		* enqueue the plugin's style and scripts
		*
		* @since 1.0.0
		*/
		function eur_enqueue_scripts_callback() {
			wp_enqueue_script('jquery');
			wp_enqueue_style('easy-user-registration-css', $this->plugin_url . 'assets/css/style.css', '', $this->version);
			wp_enqueue_script('easy-user-registration-js', $this->plugin_url . '/assets/js/script.js', array('jquery', 'wp-i18n') , $this->version, true);
			$locale = apply_filters('plugin_locale', get_locale(), 'easy-user-registration');
            $text_domain_to_load = 'easy-user-registration-'.$locale;
			wp_set_script_translations( 'easy-user-registration-js', 'easy-user-registration', trailingslashit(dirname(__FILE__)) . '../languages/');
			$WP_easy_user_registration = wp_create_nonce( 'EASY_USER_REGISTRATION' );
			wp_localize_script( 'easy-user-registration-js', 'ajax', array(
					'ajax_url' => admin_url( 'admin-ajax.php' ),
					'nonce'        => $WP_easy_user_registration,
				)
			);	
		}     
		/**
		* Registers the function as a shortcode
		*
		* @since 1.0.0
		*/
		function eur_registration_form_shortcode($attr) {
			ob_start();
			if ( is_file( $this->plugin_path . 'includes/eur-user-registration-form.php' ) ) {	
				include_once $this->plugin_path . 'includes/eur-user-registration-form.php';
				eur_custom_registration_function();
			}
			return ob_get_clean();
		}

		/**
		* Registers the ajax call function
		*
		* @since 1.0.0
		*/
		function eur_register_user_callback() {
			if ( is_file( $this->plugin_path . '/includes/ajax/eur-register-user-form-callback.php' ) ) {	
				include_once $this->plugin_path . '/includes/ajax/eur-register-user-form-callback.php';
			}	
		}
	}
}

/**
 * Returns the main instance of easy_user_registration.
 *
 * @since  1.0.0
 * @return easy_user_registration
 */

if( ! function_exists( 'eur' ) ) {
	function eur() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
		return easy_user_registration::instance();
	}
}

// Global for backwards compatibility.
$GLOBALS['eur'] = eur();