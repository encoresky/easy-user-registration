const { __ } = wp.i18n;
const displayError = function (input, msg, error) {
    input.nextElementSibling.innerHTML = msg;
    input.nextElementSibling.style.display = "block";
    error[input.name] = true;
    return false;
}
const displayNone = function (input, error) {
    input.nextElementSibling.style.display = "none";
    error[input.name] = false;
    return true;
}
const validate = function (form, input, error) {
    input.value == '' ? displayError(input, __('Field is required', 'easy-user-registration'), error) : displayNone(input, error);
    if (input.name == 'eur_email') {
        let regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
        let emailValue = input.value;
        if (emailValue == '') {
            displayError(input, __('Email address is required.', 'easy-user-registration'), error);
        }
        else if (!regex.test(emailValue)) {
            input.classList.add('invalid');
            displayError(input, __('Email address is invalid.', 'easy-user-registration'), error);

        } else {
            input.classList.remove('invalid');
            displayNone(input, error);
        }
    }
    if (input.name == 'eur_confirm_password') {
        const password = form.querySelector('[name="eur_password"]').value;
        if (input.value !== password) {
            displayError(input, __('Password is not matching', 'easy-user-registration'), error);
        } else {
            displayNone(input, error);
        }
    }
}
const wpForms = document.querySelectorAll('.eur_user_registration');

var ajax_url = ajax.ajax_url;
var nonce = ajax.nonce;
wpForms.forEach(function (form, index) {
    var error = {};
    const id = wpForms[index];
    const inputs = id.elements;
    var inputLength = inputs.length;
    for (i = 0; i < inputLength; i++) {
        inputs[i].addEventListener('blur', (e) => {
            validate(form, e.target, error);
        });
    }
    form.addEventListener('submit', function (e) {
        // prevent the form from submitting
        e.preventDefault();
        // Iterate over the form controls

        for (i = 0; i < inputLength; i++) {
            validate(form, inputs[i], error);
        }
        const areError = Object.values(error).some(
            value => value === true
        );
        if (areError) {
            return false;
        }
        const formData = new FormData(form);
        var formDataObj = {};
        for (var pair of formData.entries()) {
            formDataObj = { ...formDataObj, [pair[0]]: pair[1] }
        }
        if (formDataObj) {
            formDataObj = {
                ...formDataObj,
                action: 'eur_register_user',
                _ajax_nonce: nonce,
            }
        }
        const submitText = form.querySelector(".submit").value;
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function (event) {
            if (this.readyState == 1) {
                form.querySelector(".submit").value = "";
                form.querySelector('.eur_loader').style.display = 'block';
            }
            if (this.readyState == 4 && this.status == 200) {
                res = JSON.parse(this.responseText)
                let isSuccess = res.success;
                if (isSuccess) {
                    //After user successfully created, empty the form fields
                    id.reset();
                    let popUp = document.querySelector('.success-popup');
                    popUp.style.display = 'block';
                    //Hide the success popup after five second
                    setTimeout(function () {
                        popUp.style.display = 'none';
                    }, 5000);
                } else {
                    let errorObject = res.data;
                    if (!Object.keys(errorObject).length) return;
                    Object.keys(errorObject).forEach(function (key) {
                        let input = form.querySelector('[name=' + key + ']');
                        displayError(input, errorObject[key], error)
                    });
                }
                form.querySelector(".submit").value = submitText;
                form.querySelector('.eur_loader').style.display = 'none';
            }

        };
        xhttp.open("POST", ajax_url, true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
        xhttp.send(new URLSearchParams(formDataObj).toString());
    });
});