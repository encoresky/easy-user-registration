<?php
/*
***
*
User Registration form
**/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
function eur_registration_form( $username, $password, $email, $first_name, $last_name ) {
	if(is_user_logged_in()) {
		__('User is Logged in', 'easy-user-registration');
		$current_user = wp_get_current_user();
		$output = '<h2>' . sprintf( __( 'Howdy %s' ), $current_user->user_login ) . '</h2>';
		$output .= '<p>' . wp_loginout( get_permalink(), false ) . '</p>';
		echo wp_kses_post($output);;
	}
	else {      
		
		echo '
		<div class="eur-user-registration-form">
		<h2>'.apply_filters('eur_user_form_heading', __('User Registration', 'easy-user-registration') ).'</h2>
		<!-- User Registration Start-->
			'.do_action("eur_before_register_form").'
			<form class="eur_user_registration" method="post">
				<div class="form-field">
					<div class="form-input">
						<input placeholder="'. esc_attr__('First Name', 'easy-user-registration').'" type="text" name="eur_firstname"  value="">
						<p class="error-messages"> *First Name is required </p> 
					</div>
					<div class="form-input">
						<input placeholder="'. esc_attr__('Last Name', 'easy-user-registration') .'" type="text" name="eur_lastname"  value="">
						<p class="error-messages"> *Last Name is required  </p> 
					</div>
				</div>					
				<div class="form-field">
					<div class="form-input">
						<input placeholder="'. esc_attr__('Username', 'easy-user-registration') .'" type="text" class="form_input" name="eur_username"  value="">
						<p class="error-messages"> *Username is required</p> 
					</div>
					<div class="form-input">
						<input placeholder="'. esc_attr__('Email', 'easy-user-registration') .'" type="text" class="form_input eur_email" name="eur_email"  value="">
						<p class="form-text text-muted invalid-feedback error-messages"> *Email address is required</p>
					</div>
				</div>
				<div class="form-field email-field">
					<div class="form-input">
						<input placeholder="'. esc_attr__('Password', 'easy-user-registration') .'" type="password" name="eur_password" value="">
						<p class="error-messages"> *Password is required</p> 
					</div>
					<div class="form-input">
						<input placeholder="'. esc_attr__('Confirm Password', 'easy-user-registration') .'" type="password" name="eur_confirm_password" value="">
						<p class="error-messages"> *Password is required</p> 
					</div>
				</div>
				<div class="form-submit">
					<input type="submit" class="submit" name="eur_register_button" value="'.apply_filters('eur_user_form_submit_text', __('Register','easy-user-registration')).'"/>
					<!-- Image loader -->
					<div class="eur_loader" style="display: none;">
						<img src="'.plugin_dir_url( __DIR__ )."assets/images/loader.svg".'" />
					</div>
					<!-- Image loader -->
				</div>
				
			</form>
			'.do_action("eur_after_register_form").'
			<!-- User Registration Start-->	
			<!-- User Success Message Pop-up Start-->
			<section class="success-popup">
				<div class="popup-block">
					<div class="popup">
						<svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 48 48" width="96px" height="96px"><path fill="#4caf50" d="M44,24c0,11.045-8.955,20-20,20S4,35.045,4,24S12.955,4,24,4S44,12.955,44,24z"/><path fill="#ccff90" d="M34.602,14.602L21,28.199l-5.602-5.598l-2.797,2.797L21,33.801l16.398-16.402L34.602,14.602z"/></svg>
						<h2>'. esc_attr__('Awesome!!!', 'easy-user-registration') .'</h2>
						<p class="text-center">'. esc_attr__('User has been created successfully.', 'easy-user-registration') .'</p>
						<div class="close"></div>
					</div>
				</div>
			</section>
			<!-- User Success Message Pop-up End-->
		</div>';
	}
}
function eur_custom_registration_function() {
	// sanitize user form input
	global $username, $password, $email, $first_name, $last_name, $phone;

    eur_registration_form(
		$username,
		$password,
        $email,
        $first_name,
        $last_name,
        $phone
	);
}
?>