<?php
//check for valid nonce
if ( check_ajax_referer( 'EASY_USER_REGISTRATION', 'nonce', false ) == false ) {
	wp_send_json_error(array(
		'status' => 'fail',
		'title' => __( 'Error!', 'wp-delete-user-accounts' ),
		'message' => __( 'Request failed security check.')
	));
}
global $reg_errors;
$reg_errors = new WP_Error; // error obj
global $username, $password, $email, $first_name, $last_name;

$max_username_length = 4;
$max_password_length = 6;

$username   =   !empty($_POST['eur_username']) ? sanitize_user($_POST['eur_username']) : "";
$password   =   !empty($_POST['eur_password']) ? $_POST['eur_password'] : "";
$email      =   !empty($_POST['eur_email']) ? sanitize_email($_POST['eur_email']) : "";
$first_name =   !empty($_POST['eur_firstname']) ? sanitize_text_field($_POST['eur_firstname']) : "";
$last_name  =   !empty($_POST['eur_lastname']) ? sanitize_text_field($_POST['eur_lastname']) : "";


if ( empty( $username ) || empty( $password ) || empty( $email ) ) {
	$reg_errors->add('field', '*Required form field is missing');
}

if ( $max_username_length > strlen( $username ) ) {
	$reg_errors->add( 'eur_username', sprintf(  __('Username too short. At least %d characters is required', 'easy-user-registration'),$max_username_length));
}

if ( username_exists( $username ) ) {
	$reg_errors->add('eur_username', sprintf(  __('*Sorry, %s already exists!', 'easy-user-registration'),$username));
}

if ( $max_password_length > strlen( $password ) ) {
	$reg_errors->add( 'eur_password', sprintf(__('Password length must be greater than %d', 'easy-user-registration'), $max_password_length));
}

if ( !is_email( $email ) ) {
	$reg_errors->add( 'eur_email', __('Email is not valid', 'easy-user-registration'));
}

if ( email_exists( $email ) ) {
	$reg_errors->add( 'eur_email', __('*Email Already in use', 'easy-user-registration'));
}

if ( 1 <= count( $reg_errors->get_error_messages() ) ) {
	$errorArray = array();
	foreach ( $reg_errors as $values ) {
		foreach($values as $key=>$value) {
			$errorArray[$key] = $value[0];
		}				
	}
	wp_send_json_error($errorArray);
}

$userdata = array(
	'first_name'    =>   sanitize_text_field( $_POST['eur_firstname'] ),
	'last_name'     =>   sanitize_text_field( $_POST['eur_lastname'] ),
	'user_login'    =>   sanitize_user( $_POST['eur_username'] ),
	'user_email'    =>   sanitize_email( $_POST['eur_email'] ),
	'user_pass'     =>   $_POST['eur_password'] ,
);

//before user registration action
do_action('eur_before_user_registration', $userdata);

//insert the user data
$user = wp_insert_user( $userdata );
if( ! is_wp_error($user) ) {
	$user_data = get_user_by( 'id', $user );
	
	// after user registration action
	do_action('eur_after_user_registration', $user_data);
	
	wp_send_json_success( array( 'message' => __('User has been created successfully', 'easy-user-registration') ) );	
}
wp_die();

?>